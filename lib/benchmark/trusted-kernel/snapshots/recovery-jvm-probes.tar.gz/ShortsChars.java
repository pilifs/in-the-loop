import com.google.common.primitives.Chars;
import com.google.common.primitives.Shorts;
// Setup probe: Guava 33.4.8 Shorts.indexOf / Chars.indexOf over six 16-bit patterns (this probe's choice, including
// 0x8000 and 0xffff): all length-2 arrays and every target, 216 calls per type. Compared with a correct oracle and with
// a model that applies the wrong extension to the loaded cell only.
public final class ShortsChars {
    static final int[] P = {0x0000, 0x0001, 0x7fff, 0x8000, 0x8001, 0xffff};
    public static void main(String[] args) {
        int sCalls = 0, sOk = 0, sWrong = 0, cCalls = 0, cOk = 0, cWrong = 0;
        for (int x : P) for (int y : P) for (int t : P) {
            short[] sa = {(short) x, (short) y}; short st = (short) t;
            int r = Shorts.indexOf(sa, st); int ok = -1, bad = -1;
            for (int i = 1; i >= 0; i--) { if (sa[i] == st) ok = i; if ((sa[i] & 0xffff) == st) bad = i; }
            sCalls++; if (r == ok) sOk++; if (bad != r) sWrong++;
            char[] ca = {(char) x, (char) y}; char ct = (char) t;
            r = Chars.indexOf(ca, ct); ok = -1; bad = -1;
            for (int i = 1; i >= 0; i--) { if (ca[i] == ct) ok = i; if ((short) ca[i] == ct) bad = i; }
            cCalls++; if (r == ok) cOk++; if (bad != r) cWrong++;
        }
        System.out.println("shorts calls=" + sCalls + " agreeOracle=" + sOk + " distinguishWrongExtension=" + sWrong);
        System.out.println("chars calls=" + cCalls + " agreeOracle=" + cOk + " distinguishWrongExtension=" + cWrong);
    }
}
