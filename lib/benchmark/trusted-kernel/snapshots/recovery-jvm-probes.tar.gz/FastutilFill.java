import it.unimi.dsi.fastutil.ints.IntArrays;
import java.util.Arrays;
// Setup probe: fastutil 8.5.15 IntArrays.fill(int[],int,int,int): lengths 0-4, all arrays over {-1,0,1}, every valid
// range, five fill values (this probe's choice), against a plain loop.
public final class FastutilFill {
    static final int[] VALUES = {2, -2, 7, Integer.MIN_VALUE, Integer.MAX_VALUE};
    @SuppressWarnings("deprecation")
    public static void main(String[] args) {
        int checks = 0, pass = 0, zeroOrigin = 0, other = 0;
        for (int n = 0; n <= 4; n++) {
            int combos = (int) Math.pow(3, n);
            for (int c = 0; c < combos; c++) {
                int[] base = new int[n]; for (int i = 0, x = c; i < n; i++, x /= 3) base[i] = x % 3 - 1;
                for (int from = 0; from <= n; from++) for (int to = from; to <= n; to++) for (int v : VALUES) {
                    int[] real = base.clone(); IntArrays.fill(real, from, to, v);
                    int[] want = base.clone(); for (int i = from; i < to; i++) want[i] = v;
                    checks++; if (Arrays.equals(real, want)) pass++; if (from == 0) zeroOrigin++; else other++;
                }
            }
        }
        System.out.println("checks=" + checks + " pass=" + pass + " zeroOriginBranch=" + zeroOrigin + " otherBranch=" + other);
        int[] a = {0, 0, 0}; IntArrays.fill(a, 0, 2, 99); System.out.println("[0,2) value 99 on [0,0,0] -> " + Arrays.toString(a));
        int[] b = {5, 6, 7}; IntArrays.fill(b, 1, 1, 99); System.out.println("[1,1) value 99 on [5,6,7] -> " + Arrays.toString(b));
        for (int[] bad : new int[][]{{-1, 0, 2}, {1, 0, 2}, {0, 3, 2}}) {
            try { IntArrays.fill(new int[bad[2]], bad[0], bad[1], 1); System.out.println(Arrays.toString(bad) + " normal"); }
            catch (RuntimeException e) { System.out.println("from=" + bad[0] + " to=" + bad[1] + " len=" + bad[2] + " -> " + e.getClass().getName() + ": " + e.getMessage()); }
        }
    }
}
