import java.util.Arrays;
// Setup probe: Arrays.fill(long[],int,int,long) on Temurin 21 over lengths 0-4, every valid range, seven values.
// The value set and sentinel cells are this probe's choice; the brief does not list its grid.
public final class LongFill {
    static final long[] VALUES = {0L, 1L, -1L, 4294967296L, Long.MIN_VALUE, Long.MAX_VALUE, 0x80000000L};
    static long[] cells(int n) { long[] a = new long[n]; for (int i = 0; i < n; i++) a[i] = 0x0123456789ABCDEFL + 7919L * i; return a; }
    public static void main(String[] args) {
        int checks = 0, pass = 0, narrowChanged = 0, extendChanged = 0, empty = 0, whole = 0;
        for (int n = 0; n <= 4; n++) for (int from = 0; from <= n; from++) for (int to = from; to <= n; to++) for (long v : VALUES) {
            long[] real = cells(n); Arrays.fill(real, from, to, v);
            long[] want = cells(n); for (int i = from; i < to; i++) want[i] = v;
            long[] narrow = cells(n); for (int i = from; i < to; i++) narrow[i] = (long) (int) v;
            long[] extend = cells(n); for (int i = from; i < Math.min(to + 1, n); i++) extend[i] = v;
            checks++; if (Arrays.equals(real, want)) pass++;
            if (!Arrays.equals(real, narrow)) narrowChanged++;
            if (!Arrays.equals(real, extend)) extendChanged++;
            if (from == to) empty++; if (from == 0 && to == n && n > 0) whole++;
        }
        long[] one = {0L}; Arrays.fill(one, 0, 1, 4294967296L);
        System.out.println("checks=" + checks + " pass=" + pass + " narrowChanged=" + narrowChanged + " extendChanged=" + extendChanged + " emptyRangeChecks=" + empty + " wholeRangeChecks=" + whole);
        System.out.println("oneCell4294967296 -> " + one[0] + " (narrowed would be " + (long) (int) 4294967296L + ")");
        for (int[] bad : new int[][]{{-1, 0, 2}, {1, 0, 2}, {0, 3, 2}}) {
            try { Arrays.fill(new long[bad[2]], bad[0], bad[1], 1L); System.out.println(Arrays.toString(bad) + " normal"); }
            catch (RuntimeException e) { System.out.println("from=" + bad[0] + " to=" + bad[1] + " len=" + bad[2] + " -> " + e.getClass().getName()); }
        }
    }
}
