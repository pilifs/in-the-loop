import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.HexFormat;
// Setup probe: Ints.indexOf / Longs.indexOf in one JAR (Guava 31.1-jre or Beam's relocated Guava 32.1.2) against a
// first-match oracle, every array over a small value set (this probe's choice, not the brief's grid). Prints the digest
// of each class as loaded.
public final class IndexOfReleases {
    public static void main(String[] args) throws Exception {
        String pkg = args[1];
        try (URLClassLoader cl = new URLClassLoader(new URL[]{Path.of(args[0]).toUri().toURL()}, null)) {
            for (String n : new String[]{"Ints", "Longs"}) {
                Class<?> c = Class.forName(pkg + "." + n, true, cl);
                byte[] b = cl.getResourceAsStream(pkg.replace('.', '/') + "/" + n + ".class").readAllBytes();
                System.out.println(n + " loaded sha256 " + HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(b)));
            }
            long[] iv = {Integer.MIN_VALUE, -1, 0, 7, Integer.MAX_VALUE};
            long[] lv = {Long.MIN_VALUE, -1, 0, 7, 4294967296L, Long.MAX_VALUE};
            Method mi = Class.forName(pkg + ".Ints", true, cl).getMethod("indexOf", int[].class, int.class);
            Method ml = Class.forName(pkg + ".Longs", true, cl).getMethod("indexOf", long[].class, long.class);
            int[] r = run(mi, iv, false); System.out.println("int calls=" + r[0] + " agree=" + r[1] + " heapUnchanged=" + r[2]);
            r = run(ml, lv, true); System.out.println("long calls=" + r[0] + " agree=" + r[1] + " heapUnchanged=" + r[2]);
        }
    }
    static int[] run(Method m, long[] vals, boolean wide) throws Exception {
        int calls = 0, agree = 0, same = 0;
        for (int n = 0; n <= 3; n++) {
            int combos = (int) Math.pow(vals.length, n);
            for (int c = 0; c < combos; c++) {
                long[] cells = new long[n]; for (int i = 0, x = c; i < n; i++, x /= vals.length) cells[i] = vals[x % vals.length];
                for (long t : vals) {
                    Object arr; Object tgt;
                    if (wide) { arr = cells.clone(); tgt = t; } else { int[] a = new int[n]; for (int i = 0; i < n; i++) a[i] = (int) cells[i]; arr = a; tgt = (int) t; }
                    int got = (Integer) m.invoke(null, arr, tgt), want = -1;
                    for (int i = 0; i < n; i++) if (cells[i] == t) { want = i; break; }
                    calls++; if (got == want) agree++;
                    boolean un = true; for (int i = 0; i < n; i++) un &= (wide ? ((long[]) arr)[i] : ((int[]) arr)[i]) == cells[i]; if (un) same++;
                }
            }
        }
        return new int[]{calls, agree, same};
    }
}
