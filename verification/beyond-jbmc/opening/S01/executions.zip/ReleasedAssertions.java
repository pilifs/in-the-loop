public final class ReleasedAssertions {
public static void intact() throws Exception { assert InterfaceClaims.intact(); }
public static void intactReach() throws Exception { InterfaceClaims.intact(); assert false; }
public static void inverse() throws Exception { assert InterfaceClaims.inverse(); }
public static void inverseReach() throws Exception { InterfaceClaims.inverse(); assert false; }
public static void defensiveCopies() throws Exception { assert InterfaceClaims.defensiveCopies(); }
public static void defensiveCopiesReach() throws Exception { InterfaceClaims.defensiveCopies(); assert false; }
}
