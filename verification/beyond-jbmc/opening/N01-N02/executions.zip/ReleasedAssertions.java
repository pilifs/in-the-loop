public final class ReleasedAssertions {
public static void range(float x, float y) throws Exception { assert Product.range(x, y); }
public static void rangeReach() throws Exception { Product.range(1.5f, 2.5f); assert false; }
public static void underflow(float x, float y) throws Exception { assert Product.underflow(x, y); }
public static void underflowReach() throws Exception { Product.underflow(0x1p-75f, 0x1p-75f); assert false; }
public static void positive(float x, float y) throws Exception { assert Product.positive(x, y); }
public static void positiveReach() throws Exception { Product.positive(0x1.8p-75f, 0x1.8p-75f); assert false; }
public static void unrounded(float x, float y) throws Exception { assert Product.unrounded(x, y); }
public static void unroundedReach() throws Exception { Product.unrounded(1.5f, 2.5f); assert false; }
}
