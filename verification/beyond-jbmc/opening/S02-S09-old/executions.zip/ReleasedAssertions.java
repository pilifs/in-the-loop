public final class ReleasedAssertions {
public static void resolved() throws Exception { assert SpringTypes.resolved(); }
public static void resolvedReach() throws Exception { SpringTypes.resolved(); assert false; }
public static void unresolved() throws Exception { assert SpringTypes.unresolved(); }
public static void unresolvedReach() throws Exception { SpringTypes.unresolved(); assert false; }
public static void methodReturn() throws Exception { assert SpringTypes.methodReturn(); }
public static void methodReturnReach() throws Exception { SpringTypes.methodReturn(); assert false; }
public static void releasedSignature() throws Exception { assert SpringTypes.releasedSignature(); }
public static void releasedSignatureReach() throws Exception { SpringTypes.releasedSignature(); assert false; }
public static void afterClear() throws Exception { assert SpringTypes.afterClear(); }
public static void afterClearReach() throws Exception { SpringTypes.afterClear(); assert false; }
}
