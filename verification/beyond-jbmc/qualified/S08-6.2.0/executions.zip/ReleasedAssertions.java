public final class ReleasedAssertions {
public static void intended(int order) throws Exception { assert OptionalAssembler.intended(order); }
public static void intendedReach() throws Exception { OptionalAssembler.intended(0); assert false; }
public static void otherAbsent(int order) throws Exception { assert OptionalAssembler.otherAbsent(order); }
public static void otherAbsentReach() throws Exception { OptionalAssembler.otherAbsent(0); assert false; }
}
