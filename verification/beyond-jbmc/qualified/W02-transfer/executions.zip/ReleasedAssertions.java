public final class ReleasedAssertions {
public static void littleEndian(long word) throws Exception { assert FarmFrame.littleEndian(word); }
public static void littleEndianReach() throws Exception { FarmFrame.littleEndian(0L); assert false; }
public static void flipped(long word) throws Exception { assert FarmFrame.flipped(word); }
public static void flippedReach() throws Exception { FarmFrame.flipped(0L); assert false; }
}
