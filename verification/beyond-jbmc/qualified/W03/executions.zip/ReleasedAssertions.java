public final class ReleasedAssertions {
public static void shortOldNew(short v) throws Exception { assert MoreWireClaims.shortOldNew(v); }
public static void shortOldNewReach() throws Exception { MoreWireClaims.shortOldNew((short)0); assert false; }
public static void shortNewOld(short v) throws Exception { assert MoreWireClaims.shortNewOld(v); }
public static void shortNewOldReach() throws Exception { MoreWireClaims.shortNewOld((short)0); assert false; }
public static void longOldNew(long v) throws Exception { assert MoreWireClaims.longOldNew(v); }
public static void longOldNewReach() throws Exception { MoreWireClaims.longOldNew(0L); assert false; }
public static void longNewOld(long v) throws Exception { assert MoreWireClaims.longNewOld(v); }
public static void longNewOldReach() throws Exception { MoreWireClaims.longNewOld(0L); assert false; }
}
