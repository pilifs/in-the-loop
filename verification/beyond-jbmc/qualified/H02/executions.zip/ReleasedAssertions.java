public final class ReleasedAssertions {
public static void walk(int topology, int start) throws Exception { assert HeapTopology.walk(topology, start); }
public static void walkReach() throws Exception { HeapTopology.walk(0, -1); assert false; }
}
