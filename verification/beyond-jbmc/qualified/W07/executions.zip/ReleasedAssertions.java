public final class ReleasedAssertions {
public static void uint32OldNew(int n) throws Exception { assert MoreWireClaims.uint32OldNew(n); }
public static void uint32OldNewReach() throws Exception { MoreWireClaims.uint32OldNew(0); assert false; }
public static void uint32NewOld(int n) throws Exception { assert MoreWireClaims.uint32NewOld(n); }
public static void uint32NewOldReach() throws Exception { MoreWireClaims.uint32NewOld(0); assert false; }
public static void uint64OldNew(long n) throws Exception { assert MoreWireClaims.uint64OldNew(n); }
public static void uint64OldNewReach() throws Exception { MoreWireClaims.uint64OldNew(0L); assert false; }
public static void uint64NewOld(long n) throws Exception { assert MoreWireClaims.uint64NewOld(n); }
public static void uint64NewOldReach() throws Exception { MoreWireClaims.uint64NewOld(0L); assert false; }
public static void sint64OldNew(long n) throws Exception { assert MoreWireClaims.sint64OldNew(n); }
public static void sint64OldNewReach() throws Exception { MoreWireClaims.sint64OldNew(0L); assert false; }
public static void sint64NewOld(long n) throws Exception { assert MoreWireClaims.sint64NewOld(n); }
public static void sint64NewOldReach() throws Exception { MoreWireClaims.sint64NewOld(0L); assert false; }
}
