public final class ReleasedAssertions {
public static void pre(String digits) throws Exception { assert VersionOrder.pre(digits); }
public static void preReach() throws Exception { VersionOrder.pre("0"); assert false; }
public static void overflow(String digits) throws Exception { assert VersionOrder.overflow(digits); }
public static void overflowReach() throws Exception { VersionOrder.overflow("0"); assert false; }
}
