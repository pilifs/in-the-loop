public final class ReleasedAssertions {
public static void zeroEquals() throws Exception { assert BoxedFP.zeroEquals(); }
public static void zeroEqualsReach() throws Exception { BoxedFP.zeroEquals(); assert false; }
public static void zeroHashes() throws Exception { assert BoxedFP.zeroHashes(); }
public static void zeroHashesReach() throws Exception { BoxedFP.zeroHashes(); assert false; }
public static void nanEquality(long x, long y) throws Exception { assert BoxedFP.nanEquality(x, y); }
public static void nanEqualityReach() throws Exception { BoxedFP.nanEquality(0x7ff8000000000001L, 0xfff8000000000000L); assert false; }
public static void nanOrder(long x, long y) throws Exception { assert BoxedFP.nanOrder(x, y); }
public static void nanOrderReach() throws Exception { BoxedFP.nanOrder(0x7ff8000000000001L, 0xfff8000000000000L); assert false; }
}
