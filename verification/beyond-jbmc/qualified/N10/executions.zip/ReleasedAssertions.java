public final class ReleasedAssertions {
public static void underflow(double x, double y) throws Exception { assert DoubleProduct.underflow(x, y); }
public static void underflowReach() throws Exception { DoubleProduct.underflow(0x1p-538, 0x1p-537); assert false; }
}
