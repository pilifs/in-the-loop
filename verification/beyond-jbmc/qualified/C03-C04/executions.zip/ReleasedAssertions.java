public final class ReleasedAssertions {
public static void chunks(byte[] a, int off, int len, int split, int seed) throws Exception { assert Incremental.chunks(a, off, len, split, seed); }
public static void chunksReach() throws Exception { Incremental.chunks(new byte[0], 0, 0, 0, 0); assert false; }
public static void resetThree(byte[] a, int first, int second, int seed) throws Exception { assert Incremental.resetThree(a, first, second, seed); }
public static void resetThreeReach() throws Exception { Incremental.resetThree(new byte[0], 0, 0, 0); assert false; }
}
