public final class ReleasedAssertions {
public static void fifthLength(int ordinal) throws Exception { assert JacksonExtended.fifthLength(ordinal); }
public static void fifthLengthReach() throws Exception { JacksonExtended.fifthLength(11111); assert false; }
public static void exerciseNegative() throws Exception { assert JacksonExtended.exerciseNegative(); }
public static void exerciseNegativeReach() throws Exception { JacksonExtended.exerciseNegative(); assert false; }
}
