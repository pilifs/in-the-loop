public final class ReleasedAssertions {
public static void terminates(int topology, int start) throws Exception { assert SelfOnly.terminates(topology, start); }
public static void terminatesReach() throws Exception { SelfOnly.terminates(0, 0); assert false; }
}
