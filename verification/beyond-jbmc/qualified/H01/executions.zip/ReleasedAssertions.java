public final class ReleasedAssertions {
public static void entry(HeapTopology.Cell[] cells) throws Exception { assert HeapTopology.entry(cells); }
public static void entryReach() throws Exception { HeapTopology.entry(new HeapTopology.Cell[]{HeapTopology.cell(new org.apache.commons.lang3.mutable.MutableInt(-1))}); assert false; }
public static void constructed(int value, int mode) throws Exception { assert HeapTopology.constructed(value, mode); }
public static void constructedReach() throws Exception { HeapTopology.constructed(0, 0); assert false; }
public static void unchanged(int value) throws Exception { assert HeapTopology.unchanged(value); }
public static void unchangedReach() throws Exception { HeapTopology.unchanged(-1); assert false; }
}
