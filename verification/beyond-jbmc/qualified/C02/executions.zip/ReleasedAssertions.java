public final class ReleasedAssertions {
public static void tail(byte[] a, int off, int len, int seed) throws Exception { assert Incremental.tail(a, off, len, seed); }
public static void tailReach() throws Exception { Incremental.tail(new byte[0], 0, 0, -1); assert false; }
}
