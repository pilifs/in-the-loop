public final class ReleasedAssertions {
public static void planes(char[][][] data) throws Exception { assert SuppliedRoots.planes(data); }
public static void planesReach() throws Exception { SuppliedRoots.planes(new char[][][]{{{'a'}},{{'b'}}}); assert false; }
public static void conditional(SuppliedRoots.Flat[] a, SuppliedRoots.Flat[] b) throws Exception { assert SuppliedRoots.conditional(a, b); }
public static void conditionalReach() throws Exception { SuppliedRoots.conditional(new SuppliedRoots.Flat[]{new SuppliedRoots.Flat(), new SuppliedRoots.Flat()}, new SuppliedRoots.Flat[]{new SuppliedRoots.Flat()}); assert false; }
public static void unconditional(SuppliedRoots.Flat[] a, SuppliedRoots.Flat[] b) throws Exception { assert SuppliedRoots.unconditional(a, b); }
public static void unconditionalReach() throws Exception { SuppliedRoots.unconditional(new SuppliedRoots.Flat[]{new SuppliedRoots.Flat(), new SuppliedRoots.Flat()}, new SuppliedRoots.Flat[]{new SuppliedRoots.Flat()}); assert false; }
public static void scalar(SuppliedRoots.Flat[] a, SuppliedRoots.Flat b) throws Exception { assert SuppliedRoots.scalar(a, b); }
public static void scalarReach() throws Exception { SuppliedRoots.scalar(new SuppliedRoots.Flat[]{new SuppliedRoots.Flat()}, new SuppliedRoots.Flat()); assert false; }
public static void dispatch(SuppliedRoots.Base[] a) throws Exception { assert SuppliedRoots.dispatch(a); }
public static void dispatchReach() throws Exception { SuppliedRoots.dispatch(new SuppliedRoots.Base[]{new SuppliedRoots.Base()}); assert false; }
public static void noSelf(SuppliedRoots.Node[] a) throws Exception { assert SuppliedRoots.noSelf(a); }
public static void noSelfReach() throws Exception { SuppliedRoots.noSelf(new SuppliedRoots.Node[]{new SuppliedRoots.Node()}); assert false; }
}
