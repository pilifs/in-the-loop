public final class ReleasedAssertions {
public static void caret(int range, int v) throws Exception { assert VersionOrder.caret(range, v); }
public static void caretReach() throws Exception { VersionOrder.caret(0, 0); assert false; }
}
