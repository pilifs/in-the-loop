public final class ReleasedAssertions {
public static void form(boolean html) throws Exception { assert MarkupHistory.form(html); }
public static void formReach() throws Exception { MarkupHistory.form(true); assert false; }
public static void reparent() throws Exception { assert MarkupHistory.reparent(); }
public static void reparentReach() throws Exception { MarkupHistory.reparent(); assert false; }
}
