public final class ReleasedAssertions {
public static void listener(boolean list) throws Exception { assert SpringHistories.listener(list); }
public static void listenerReach() throws Exception { SpringHistories.listener(true); assert false; }
}
