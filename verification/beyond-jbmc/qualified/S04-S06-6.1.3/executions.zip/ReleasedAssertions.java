public final class ReleasedAssertions {
public static void bridge() throws Exception { assert SpringHistories.bridge(); }
public static void bridgeReach() throws Exception { SpringHistories.bridge(); assert false; }
public static void aliases() throws Exception { assert SpringHistories.aliases(); }
public static void aliasesReach() throws Exception { SpringHistories.aliases(); assert false; }
public static void conversion() throws Exception { assert SpringHistories.conversion(); }
public static void conversionReach() throws Exception { SpringHistories.conversion(); assert false; }
}
