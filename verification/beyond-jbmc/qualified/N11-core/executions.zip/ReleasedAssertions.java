public final class ReleasedAssertions {
public static void changed(int ordinal) throws Exception { assert JacksonPartition.changed(ordinal); }
public static void changedReach() throws Exception { JacksonPartition.changed(0); assert false; }
public static void nullControl() throws Exception { assert JacksonPartition.nullControl(); }
public static void nullControlReach() throws Exception { JacksonPartition.nullControl(); assert false; }
}
