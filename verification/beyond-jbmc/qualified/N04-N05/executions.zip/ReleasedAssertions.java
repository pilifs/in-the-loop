public final class ReleasedAssertions {
public static void arrayRange(int suffix, boolean negative, int offset) throws Exception { assert JacksonRanges.arrayRange(suffix, negative, offset); }
public static void arrayRangeReach() throws Exception { JacksonRanges.arrayRange(807, false, 1); assert false; }
public static void stringRange(int suffix, boolean negative) throws Exception { assert JacksonRanges.stringRange(suffix, negative); }
public static void stringRangeReach() throws Exception { JacksonRanges.stringRange(807, false); assert false; }
public static void accepted(int suffix, boolean negative, int offset) throws Exception { assert JacksonRanges.accepted(suffix, negative, offset); }
public static void acceptedReach() throws Exception { JacksonRanges.accepted(807, false, 1); assert false; }
public static void allDigits(char[] text, int offset, boolean negative) throws Exception { assert JacksonRanges.allDigits(text, offset, negative); }
public static void allDigitsReach() throws Exception { JacksonRanges.allDigits("x9223372036854775808y".toCharArray(), 1, true); assert false; }
}
