public final class ReleasedAssertions {
public static void signBlind(int suffix) throws Exception { assert JacksonControl.signBlind(suffix); }
public static void signBlindReach() throws Exception { JacksonControl.signBlind(807); assert false; }
public static void all19Safe() throws Exception { assert JacksonControl.all19Safe(); }
public static void all19SafeReach() throws Exception { JacksonControl.all19Safe(); assert false; }
}
