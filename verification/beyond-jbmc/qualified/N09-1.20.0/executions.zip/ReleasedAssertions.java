public final class ReleasedAssertions {
public static void box(int x, int y, int u, int v) throws Exception { assert OrientationGrid.box(x, y, u, v); }
public static void boxReach() throws Exception { OrientationGrid.box(1, 0, 0, 1); assert false; }
public static void cancellation(int n) throws Exception { assert OrientationGrid.cancellation(n); }
public static void cancellationReach() throws Exception { OrientationGrid.cancellation(1); assert false; }
}
