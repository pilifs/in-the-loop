public final class ReleasedAssertions {
public static void recordOldNew(int header, int payload) throws Exception { assert MoreWireClaims.recordOldNew(header, payload); }
public static void recordOldNewReach() throws Exception { MoreWireClaims.recordOldNew(0x01020304, 0x04030201); assert false; }
public static void recordNewOld(int header, int payload) throws Exception { assert MoreWireClaims.recordNewOld(header, payload); }
public static void recordNewOldReach() throws Exception { MoreWireClaims.recordNewOld(0x01020304, 0x04030201); assert false; }
}
