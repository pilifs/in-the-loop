public final class ReleasedAssertions {
public static void scalarRoot(int initial, boolean shared) throws Exception { assert RootShapes.scalarRoot(initial, shared); }
public static void scalarRootReach() throws Exception { RootShapes.scalarRoot(Integer.MAX_VALUE, true); assert false; }
}
