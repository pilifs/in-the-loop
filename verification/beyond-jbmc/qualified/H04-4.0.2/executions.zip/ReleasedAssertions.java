public final class ReleasedAssertions {
public static void branches(int n, int i, int replacement) throws Exception { assert PersistentVector.branches(n, i, replacement); }
public static void branchesReach() throws Exception { PersistentVector.branches(1, 0, -1); assert false; }
}
