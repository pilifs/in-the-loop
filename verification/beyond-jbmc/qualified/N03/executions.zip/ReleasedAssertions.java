public final class ReleasedAssertions {
public static void rounds(int n) throws Exception { assert Cancellation.rounds(n); }
public static void roundsReach() throws Exception { Cancellation.rounds(1); assert false; }
public static void fused(int n) throws Exception { assert Cancellation.fused(n); }
public static void fusedReach() throws Exception { Cancellation.fused(2048); assert false; }
}
