public final class ReleasedAssertions {
public static void oldNew(int header, int payload) throws Exception { assert PayloadFirstClaims.oldNew(header, payload); }
public static void oldNewReach() throws Exception { PayloadFirstClaims.oldNew(0x01020304, 0x04030201); assert false; }
public static void newOld(int header, int payload) throws Exception { assert PayloadFirstClaims.newOld(header, payload); }
public static void newOldReach() throws Exception { PayloadFirstClaims.newOld(0x01020304, 0x04030201); assert false; }
}
