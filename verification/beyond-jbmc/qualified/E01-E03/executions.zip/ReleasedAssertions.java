public final class ReleasedAssertions {
public static void coarse(int mode) throws Exception { assert ThrowSites.coarse(mode); }
public static void coarseReach() throws Exception { ThrowSites.coarse(0); assert false; }
public static void history(int mode, boolean replace) throws Exception { assert ThrowSites.history(mode, replace); }
public static void historyReach() throws Exception { ThrowSites.history(0, true); assert false; }
}
