public final class ReleasedAssertions {
public static void newGrammar(int major, int minor, int patch, int parts, int mask) throws Exception { assert Coercion.newGrammar(major, minor, patch, parts, mask); }
public static void newGrammarReach() throws Exception { Coercion.newGrammar(1, 8, 0, 2, 0); assert false; }
public static void oldGrammar(int major, int minor, int patch, int parts, int mask) throws Exception { assert Coercion.oldGrammar(major, minor, patch, parts, mask); }
public static void oldGrammarReach() throws Exception { Coercion.oldGrammar(1, 8, 0, 2, 0); assert false; }
public static void plain() throws Exception { assert Coercion.plain(); }
public static void plainReach() throws Exception { Coercion.plain(); assert false; }
}
