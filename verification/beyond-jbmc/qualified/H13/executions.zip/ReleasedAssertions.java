public final class ReleasedAssertions {
public static void mapping(int choice) throws Exception { assert RootShapes.mapping(choice); }
public static void mappingReach() throws Exception { RootShapes.mapping(0); assert false; }
public static void alwaysFour(int choice) throws Exception { assert RootShapes.alwaysFour(choice); }
public static void alwaysFourReach() throws Exception { RootShapes.alwaysFour(0); assert false; }
}
