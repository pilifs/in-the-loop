public final class ReleasedAssertions {
public static void strings(char a, char b) throws Exception { assert CaseFolding.strings(a, b); }
public static void stringsReach() throws Exception { CaseFolding.strings('K', (char)0x212a); assert false; }
public static void sequences(char a, char b) throws Exception { assert CaseFolding.sequences(a, b); }
public static void sequencesReach() throws Exception { CaseFolding.sequences('K', (char)0x212a); assert false; }
public static void same(char a, char b) throws Exception { assert CaseFolding.same(a, b); }
public static void sameReach() throws Exception { CaseFolding.same('A', 'a'); assert false; }
public static void nulls() throws Exception { assert CaseFolding.nulls(); }
public static void nullsReach() throws Exception { CaseFolding.nulls(); assert false; }
}
