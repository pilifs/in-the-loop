public final class ReleasedAssertions {
public static void oldSchedule(long instant) throws Exception { assert ZoneChecks.oldSchedule(instant); }
public static void oldScheduleReach() throws Exception { ZoneChecks.oldSchedule(1672531200000L); assert false; }
public static void newSchedule(long instant) throws Exception { assert ZoneChecks.newSchedule(instant); }
public static void newScheduleReach() throws Exception { ZoneChecks.newSchedule(1672531200000L); assert false; }
public static void unaffected(long instant) throws Exception { assert ZoneChecks.unaffected(instant); }
public static void unaffectedReach() throws Exception { ZoneChecks.unaffected(1672531200000L); assert false; }
}
