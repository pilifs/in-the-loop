public final class ReleasedAssertions {
public static void commons(char c) throws Exception { assert Lexical.commons(c); }
public static void commonsReach() throws Exception { Lexical.commons('0'); assert false; }
public static void partition(char c) throws Exception { assert Lexical.partition(c); }
public static void partitionReach() throws Exception { Lexical.partition('0'); assert false; }
}
