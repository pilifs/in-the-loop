public final class ReleasedAssertions {
public static void subset(int hole, int d) throws Exception { assert IteratorHistories.subset(hole, d); }
public static void subsetReach() throws Exception { IteratorHistories.subset(64, 0); assert false; }
public static void interval(int hole, int d) throws Exception { assert IteratorHistories.interval(hole, d); }
public static void intervalReach() throws Exception { IteratorHistories.interval(64, 0); assert false; }
}
