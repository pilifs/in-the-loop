public final class ReleasedAssertions {
public static void arrayRoots(int x, int y, boolean shared) throws Exception { assert RootShapes.arrayRoots(x, y, shared); }
public static void arrayRootsReach() throws Exception { RootShapes.arrayRoots(7, 7, false); assert false; }
public static void unconditional(boolean shared) throws Exception { assert RootShapes.unconditional(shared); }
public static void unconditionalReach() throws Exception { RootShapes.unconditional(false); assert false; }
}
