public final class ReleasedAssertions {
public static void xml(char interior) throws Exception { assert MarkupHistory.xml(interior); }
public static void xmlReach() throws Exception { MarkupHistory.xml('a'); assert false; }
}
