public final class ReleasedAssertions {
public static void guavaString(char a, char b) throws Exception { assert FoldProfiles.guavaString(a, b); }
public static void guavaStringReach() throws Exception { FoldProfiles.guavaString('K', (char)0x212a); assert false; }
public static void guavaSequence(char a, char b) throws Exception { assert FoldProfiles.guavaSequence(a, b); }
public static void guavaSequenceReach() throws Exception { FoldProfiles.guavaSequence('K', (char)0x212a); assert false; }
public static void langString(char a, char b) throws Exception { assert FoldProfiles.langString(a, b); }
public static void langStringReach() throws Exception { FoldProfiles.langString('K', (char)0x212a); assert false; }
public static void langSequence(char a, char b) throws Exception { assert FoldProfiles.langSequence(a, b); }
public static void langSequenceReach() throws Exception { FoldProfiles.langSequence('K', (char)0x212a); assert false; }
}
