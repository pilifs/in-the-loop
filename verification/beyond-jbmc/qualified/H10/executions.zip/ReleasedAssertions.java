public final class ReleasedAssertions {
public static void planes(boolean shared, char x, char y) throws Exception { assert HeapTopology.planes(shared, x, y); }
public static void planesReach() throws Exception { HeapTopology.planes(true, 'z', 'z'); assert false; }
}
