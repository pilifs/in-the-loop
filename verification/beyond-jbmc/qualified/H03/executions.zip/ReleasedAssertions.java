public final class ReleasedAssertions {
public static void twoRoots(int value, boolean shared) throws Exception { assert HeapTopology.twoRoots(value, shared); }
public static void twoRootsReach() throws Exception { HeapTopology.twoRoots(Integer.MAX_VALUE, true); assert false; }
}
