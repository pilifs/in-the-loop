public final class ReleasedAssertions {
public static void registeredEnum() throws Exception { assert FormatterBinding.registeredEnum(); }
public static void registeredEnumReach() throws Exception { FormatterBinding.registeredEnum(); assert false; }
public static void annotated(int mode) throws Exception { assert FormatterBinding.annotated(mode); }
public static void annotatedReach() throws Exception { FormatterBinding.annotated(0); assert false; }
public static void preservation(int mode) throws Exception { assert FormatterBinding.preservation(mode); }
public static void preservationReach() throws Exception { FormatterBinding.preservation(0); assert false; }
}
