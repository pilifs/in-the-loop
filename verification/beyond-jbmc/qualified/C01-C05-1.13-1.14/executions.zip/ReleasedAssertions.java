public final class ReleasedAssertions {
public static void historicalIdentity(byte[] text, int off, int len, int seed) throws Exception { assert CodecChanges.historicalIdentity(text, off, len, seed); }
public static void historicalIdentityReach() throws Exception { CodecChanges.historicalIdentity(new byte[]{1,-1,2}, 1, 1, 0); assert false; }
public static void unchanged32(byte[] text, int off, int len, int seed) throws Exception { assert CodecChanges.unchanged32(text, off, len, seed); }
public static void unchanged32Reach() throws Exception { CodecChanges.unchanged32(new byte[]{1,-1,2}, 1, 1, 0); assert false; }
public static void seedBoundary(byte[] text, int off, int len, int seed) throws Exception { assert CodecChanges.seedBoundary(text, off, len, seed); }
public static void seedBoundaryReach() throws Exception { CodecChanges.seedBoundary(new byte[]{1,-1,2}, 1, 1, 0); assert false; }
}
