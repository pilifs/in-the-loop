public final class ReleasedAssertions {
public static void size32(int n) throws Exception { assert MoreWireClaims.size32(n); }
public static void size32Reach() throws Exception { MoreWireClaims.size32(0); assert false; }
public static void size64(long n) throws Exception { assert MoreWireClaims.size64(n); }
public static void size64Reach() throws Exception { MoreWireClaims.size64(0L); assert false; }
}
