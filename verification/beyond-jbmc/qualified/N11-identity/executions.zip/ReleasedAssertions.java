public final class ReleasedAssertions {
public static void unchanged(int ordinal) throws Exception { assert JacksonIdentity.unchanged(ordinal); }
public static void unchangedReach() throws Exception { JacksonIdentity.unchanged(1); assert false; }
public static void fixed() throws Exception { assert JacksonIdentity.fixed(); }
public static void fixedReach() throws Exception { JacksonIdentity.fixed(); assert false; }
}
