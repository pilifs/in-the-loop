public final class ReleasedAssertions {
public static void protoToLucene(int n) throws Exception { assert MoreWireClaims.protoToLucene(n); }
public static void protoToLuceneReach() throws Exception { MoreWireClaims.protoToLucene(0); assert false; }
public static void swappedEntrypoint(int n) throws Exception { assert MoreWireClaims.swappedEntrypoint(n); }
public static void swappedEntrypointReach() throws Exception { MoreWireClaims.swappedEntrypoint(127); assert false; }
}
