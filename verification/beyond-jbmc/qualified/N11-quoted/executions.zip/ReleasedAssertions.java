public final class ReleasedAssertions {
public static void partition(int ordinal, int kind) throws Exception { assert QuotedPartition.partition(ordinal, kind); }
public static void partitionReach() throws Exception { QuotedPartition.partition(0, 0); assert false; }
}
