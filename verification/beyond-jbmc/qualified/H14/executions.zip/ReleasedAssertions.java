public final class ReleasedAssertions {
public static void linked(int shape) throws Exception { assert RootShapes.linked(shape); }
public static void linkedReach() throws Exception { RootShapes.linked(0); assert false; }
public static void noSelf(int shape) throws Exception { assert RootShapes.noSelf(shape); }
public static void noSelfReach() throws Exception { RootShapes.noSelf(0); assert false; }
}
