public final class ReleasedAssertions {
public static void forward(int steps) throws Exception { assert IteratorHistories.forward(steps); }
public static void forwardReach() throws Exception { IteratorHistories.forward(0); assert false; }
public static void reverse(int alternate) throws Exception { assert IteratorHistories.reverse(alternate); }
public static void reverseReach() throws Exception { IteratorHistories.reverse(0); assert false; }
}
