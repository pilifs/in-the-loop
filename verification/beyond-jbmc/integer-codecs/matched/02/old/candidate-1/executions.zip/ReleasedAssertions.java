public final class ReleasedAssertions {
public static void primary(int n) throws Exception { assert IntegerCodec.primary(n); }
public static void primaryReach() throws Exception { IntegerCodec.primary(0); assert false; }
public static void control(int n) throws Exception { assert IntegerCodec.control(n); }
public static void controlReach() throws Exception { IntegerCodec.control(0); assert false; }
public static void inverse(int n) throws Exception { assert IntegerCodec.inverse(n); }
public static void inverseReach() throws Exception { IntegerCodec.inverse(-1); assert false; }
public static void unsigned(int n) throws Exception { assert IntegerCodec.unsigned(n); }
public static void unsignedReach() throws Exception { IntegerCodec.unsigned(0); assert false; }
}
