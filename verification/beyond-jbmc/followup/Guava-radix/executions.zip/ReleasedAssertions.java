public final class ReleasedAssertions {
public static void word(int word, boolean upper) throws Exception { assert GuavaRadix.word(word, upper); }
public static void wordReach() throws Exception { GuavaRadix.word(0, false); assert false; }
public static void outside(boolean negative) throws Exception { assert GuavaRadix.outside(negative); }
public static void outsideReach() throws Exception { GuavaRadix.outside(false); assert false; }
public static void nonnegative(int word, boolean upper) throws Exception { assert GuavaRadix.nonnegative(word, upper); }
public static void nonnegativeReach() throws Exception { GuavaRadix.nonnegative(0, true); assert false; }
}
