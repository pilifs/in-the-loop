public final class ReleasedAssertions {
public static void primary(int n) throws Exception { assert ReferencePair.primary(n); }
public static void primaryReach() throws Exception { ReferencePair.primary(0); assert false; }
public static void control(int n) throws Exception { assert ReferencePair.control(n); }
public static void controlReach() throws Exception { ReferencePair.control(0); assert false; }
public static void inverse(int n) throws Exception { assert ReferencePair.inverse(n); }
public static void inverseReach() throws Exception { ReferencePair.inverse(0); assert false; }
}
