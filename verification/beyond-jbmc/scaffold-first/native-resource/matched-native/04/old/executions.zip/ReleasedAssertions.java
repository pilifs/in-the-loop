public final class ReleasedAssertions {
public static void primary(int n) throws Exception { assert SideReference.primary(n); }
public static void primaryReach() throws Exception { SideReference.primary(0); assert false; }
public static void control(int n) throws Exception { assert SideReference.control(n); }
public static void controlReach() throws Exception { SideReference.control(0); assert false; }
public static void inverse(int n) throws Exception { assert SideReference.inverse(n); }
public static void inverseReach() throws Exception { SideReference.inverse(0); assert false; }
}
