import java.net.URL;import java.util.Enumeration;import java.io.InputStream;
public class PairResourceGate {
 public static int read(boolean select) throws Exception {
    String key=select?"META-INF/paint":"META-INF/missing";
    Enumeration<URL> hits=PairResourceGate.class.getClassLoader().getResources(key);
    if(!hits.hasMoreElements()) return -1;
    try(InputStream in=hits.nextElement().openStream()){int value=in.read();return value;}
 }
 public static void main(String[] args)throws Exception {System.out.println(read(false)+","+read(true));}
}