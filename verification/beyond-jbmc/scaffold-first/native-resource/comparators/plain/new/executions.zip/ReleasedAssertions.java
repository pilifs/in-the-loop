public final class ReleasedAssertions {
public static void primary(boolean selected) throws Exception { assert ResourceConjunct.primary(selected); }
public static void primaryReach() throws Exception { ResourceConjunct.primary(false); assert false; }
public static void wrong(boolean selected) throws Exception { assert ResourceConjunct.wrong(selected); }
public static void wrongReach() throws Exception { ResourceConjunct.wrong(false); assert false; }
}
