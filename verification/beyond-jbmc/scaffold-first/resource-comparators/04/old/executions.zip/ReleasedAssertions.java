public final class ReleasedAssertions {
public static void primary(int n) throws Exception { assert ResourcePredicate.primary(n); }
public static void primaryReach() throws Exception { ResourcePredicate.primary(0); assert false; }
public static void control(int n) throws Exception { assert ResourcePredicate.control(n); }
public static void controlReach() throws Exception { ResourcePredicate.control(0); assert false; }
public static void inverse(int n) throws Exception { assert ResourcePredicate.inverse(n); }
public static void inverseReach() throws Exception { ResourcePredicate.inverse(0); assert false; }
}
