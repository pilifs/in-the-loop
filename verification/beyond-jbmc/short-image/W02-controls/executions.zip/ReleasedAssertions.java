public final class ReleasedAssertions {
public static void signed(short value) throws Exception { assert ViewChecks.signed(value); }
public static void signedReach() throws Exception { ViewChecks.signed((short)-1); assert false; }
public static void bounds(int offset, long value) throws Exception { assert ViewChecks.bounds(offset, value); }
public static void boundsReach() throws Exception { ViewChecks.bounds(0, 1L); assert false; }
public static void atomic(long value) throws Exception { assert ViewChecks.atomic(value); }
public static void atomicReach() throws Exception { ViewChecks.atomic(0L); assert false; }
public static void opaqueIdentity() throws Exception { assert ViewChecks.opaqueIdentity(); }
public static void opaqueIdentityReach() throws Exception { ViewChecks.opaqueIdentity(); assert false; }
}
