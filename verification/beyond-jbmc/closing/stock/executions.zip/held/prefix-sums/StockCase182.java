public final class StockCase182 {
    public static int observe(int[] a) {
        if (!((a != null && a.length <= 8))) return 2;
        int[] old_a = new int[a.length];
        for (int i=0; i<a.length; ++i) old_a[i] = a[i];
        Throwable t0 = null;
        try { before.bench.held.PrefixSums.accumulate(old_a); } catch (Throwable e) { t0=e; }
        Throwable t1 = null;
        try { bench.held.PrefixSums.accumulate(a); } catch (Throwable e) { t1=e; }
        boolean normal = t0 == null && t1 == null;
        boolean equal = normal || (t0 != null && t1 != null && t0.getClass() == t1.getClass());
        for (int i=0; i<a.length; ++i) if (old_a[i] != a[i]) equal=false;
        return normal ? (equal ? 1 : 0) : (equal ? -2 : -1);
    }
    public static void target(int[] a) { int o=observe(a); assert o==2 || o==1 || o == -2; }
    public static void reach(int[] a) { int o=observe(a); assert o!=0 && o!=1; }
}
