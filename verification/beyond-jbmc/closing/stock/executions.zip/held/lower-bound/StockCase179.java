public final class StockCase179 {
    public static int observe(int[] a, int key) {
        if (!((a != null && a.length <= 8) && (a != null))) return 2;
        for (int i=0; i+1 < a.length; ++i) if (a[i] > a[i+1]) return 2;
        int[] old_a = new int[a.length];
        for (int i=0; i<a.length; ++i) old_a[i] = a[i];
        Throwable t0 = null;
        int v0 = 0;
        try { v0 = before.bench.held.LowerBound.lowerBound(old_a, key); } catch (Throwable e) { t0=e; }
        Throwable t1 = null;
        int v1 = 0;
        try { v1 = bench.held.LowerBound.lowerBound(a, key); } catch (Throwable e) { t1=e; }
        boolean normal = t0 == null && t1 == null;
        boolean equal = normal || (t0 != null && t1 != null && t0.getClass() == t1.getClass());
        if (normal && v0 != v1) equal=false;
        for (int i=0; i<a.length; ++i) if (old_a[i] != a[i]) equal=false;
        return normal ? (equal ? 1 : 0) : (equal ? -2 : -1);
    }
    public static void target(int[] a, int key) { int o=observe(a, key); assert o==2 || o==1 || o == -2; }
    public static void reach(int[] a, int key) { int o=observe(a, key); assert o!=0 && o!=1; }
}
