public final class StockCase180 {
    public static int observe(char[] cs) {
        if (!((cs != null && cs.length <= 8))) return 2;
        char[] old_cs = new char[cs.length];
        for (int i=0; i<cs.length; ++i) old_cs[i] = cs[i];
        Throwable t0 = null;
        int v0 = 0;
        try { v0 = before.bench.held.Utf8Length.length(old_cs); } catch (Throwable e) { t0=e; }
        Throwable t1 = null;
        int v1 = 0;
        try { v1 = bench.held.Utf8Length.length(cs); } catch (Throwable e) { t1=e; }
        boolean normal = t0 == null && t1 == null;
        boolean equal = normal || (t0 != null && t1 != null && t0.getClass() == t1.getClass());
        if (normal && v0 != v1) equal=false;
        for (int i=0; i<cs.length; ++i) if (old_cs[i] != cs[i]) equal=false;
        return normal ? (equal ? 1 : 0) : (equal ? -2 : -1);
    }
    public static void target(char[] cs) { int o=observe(cs); assert o==2 || o==1 || o == -2; }
    public static void reach(char[] cs) { int o=observe(cs); assert o!=0 && o!=1; }
}
