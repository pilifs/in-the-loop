public final class StockCase184 {
    public static int observe(int x_lo, int x_hi, int y_lo, int y_hi) {
        before.bench.held.Interval r0_x;
        try { r0_x = new before.bench.held.Interval(x_lo, x_hi); } catch (IllegalArgumentException e) { return 2; }
        bench.held.Interval r1_x;
        try { r1_x = new bench.held.Interval(x_lo, x_hi); } catch (IllegalArgumentException e) { return 2; }
        before.bench.held.Interval r0_y;
        try { r0_y = new before.bench.held.Interval(y_lo, y_hi); } catch (IllegalArgumentException e) { return 2; }
        bench.held.Interval r1_y;
        try { r1_y = new bench.held.Interval(y_lo, y_hi); } catch (IllegalArgumentException e) { return 2; }
        Throwable t0 = null;
        int v0 = 0;
        try { v0 = before.bench.held.Overlap.length(r0_x, r0_y); } catch (Throwable e) { t0=e; }
        Throwable t1 = null;
        int v1 = 0;
        try { v1 = bench.held.Overlap.length(r1_x, r1_y); } catch (Throwable e) { t1=e; }
        boolean normal = t0 == null && t1 == null;
        boolean equal = normal || (t0 != null && t1 != null && t0.getClass() == t1.getClass());
        if (normal && v0 != v1) equal=false;
        return normal ? (equal ? 1 : 0) : (equal ? -2 : -1);
    }
    public static void target(int x_lo, int x_hi, int y_lo, int y_hi) { int o=observe(x_lo, x_hi, y_lo, y_hi); assert o==2 || o==1 || o == -2; }
    public static void reach(int x_lo, int x_hi, int y_lo, int y_hi) { int o=observe(x_lo, x_hi, y_lo, y_hi); assert o!=0 && o!=1; }
}
