public final class StockCase177 {
    public static int observe(int a, int n) {
        if (!((!(n <= 0)))) return 2;
        Throwable t0 = null;
        int v0 = 0;
        try { v0 = before.bench.held.FloorMod.mod(a, n); } catch (Throwable e) { t0=e; }
        Throwable t1 = null;
        int v1 = 0;
        try { v1 = bench.held.FloorMod.mod(a, n); } catch (Throwable e) { t1=e; }
        boolean normal = t0 == null && t1 == null;
        boolean equal = normal || (t0 != null && t1 != null && t0.getClass() == t1.getClass());
        if (normal && v0 != v1) equal=false;
        return normal ? (equal ? 1 : 0) : (equal ? -2 : -1);
    }
    public static void target(int a, int n) { int o=observe(a, n); assert o==2 || o==1 || o == -2; }
    public static void reach(int a, int n) { int o=observe(a, n); assert o!=0 && o!=1; }
}
