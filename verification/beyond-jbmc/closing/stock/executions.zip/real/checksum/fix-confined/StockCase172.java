public final class StockCase172 {
    public static int observe(byte[] b, int off, int len) {
        if (!((b != null && b.length <= 8) && (!(off > 0 && len > 0 && off + len < 0)))) return 2;
        byte[] old_b = new byte[b.length];
        for (int i=0; i<b.length; ++i) old_b[i] = b[i];
        Throwable t0 = null;
        int v0 = 0;
        try { v0 = before.bench.real.Checksum.sum(old_b, off, len); } catch (Throwable e) { t0=e; }
        Throwable t1 = null;
        int v1 = 0;
        try { v1 = bench.real.Checksum.sum(b, off, len); } catch (Throwable e) { t1=e; }
        boolean normal = t0 == null && t1 == null;
        boolean equal = normal || (t0 != null && t1 != null && t0.getClass() == t1.getClass());
        if (normal && v0 != v1) equal=false;
        for (int i=0; i<b.length; ++i) if (old_b[i] != b[i]) equal=false;
        return normal ? (equal ? 1 : 0) : (equal ? -2 : -1);
    }
    public static void target(byte[] b, int off, int len) { int o=observe(b, off, len); assert o==2 || o==1 || o == -2; }
    public static void reach(byte[] b, int off, int len) { int o=observe(b, off, len); assert o!=0 && o!=1; }
}
