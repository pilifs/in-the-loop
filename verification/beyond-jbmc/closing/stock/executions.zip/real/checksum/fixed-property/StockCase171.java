public final class StockCase171 {
    public static int observe(byte[] b, int off, int len) {
        if (!((b != null && b.length <= 8))) return 2;
        int expected = 0;
        if (off < 0 || len < 0 || len > b.length - off) expected = 1;
        int result;
        try { result = bench.real.Checksum.sum(b, off, len); }
        catch (Throwable t) {
            if (t instanceof IndexOutOfBoundsException) return expected == 1 ? -2 : -1;
            return -1;
        }
        return expected == 0 && (len != 0 || result == 0) ? 1 : 0;
    }
    public static void target(byte[] b, int off, int len) { int o=observe(b, off, len); assert o==2 || o==1 || o == -2; }
    public static void reach(byte[] b, int off, int len) { int o=observe(b, off, len); assert o!=0 && o!=1; }
}
