public final class StockCase165 {
    public static int observe(int hash, int buckets) {
        if (!((buckets > 0))) return 2;
        int expected = 0;
        int result;
        try { result = bench.real.Bucket.index(hash, buckets); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (0 <= result && result < buckets) ? 1 : 0;
    }
    public static void target(int hash, int buckets) { int o=observe(hash, buckets); assert o==2 || o==1 || o == -2; }
    public static void reach(int hash, int buckets) { int o=observe(hash, buckets); assert o!=0 && o!=1; }
}
