public final class StockCase168 {
    public static int observe(int i) {
        int expected = 0;
        boolean result;
        try { result = bench.real.Oddity.isOdd(i); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (result == ((i & 1) == 1)) ? 1 : 0;
    }
    public static void target(int i) { int o=observe(i); assert o==2 || o==1 || o == -2; }
    public static void reach(int i) { int o=observe(i); assert o!=0 && o!=1; }
}
