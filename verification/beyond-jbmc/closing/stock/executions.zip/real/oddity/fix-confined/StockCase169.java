public final class StockCase169 {
    public static int observe(int i) {
        if (!((!(i < 0)))) return 2;
        Throwable t0 = null;
        boolean v0 = false;
        try { v0 = before.bench.real.Oddity.isOdd(i); } catch (Throwable e) { t0=e; }
        Throwable t1 = null;
        boolean v1 = false;
        try { v1 = bench.real.Oddity.isOdd(i); } catch (Throwable e) { t1=e; }
        boolean normal = t0 == null && t1 == null;
        boolean equal = normal || (t0 != null && t1 != null && t0.getClass() == t1.getClass());
        if (normal && v0 != v1) equal=false;
        return normal ? (equal ? 1 : 0) : (equal ? -2 : -1);
    }
    public static void target(int i) { int o=observe(i); assert o==2 || o==1 || o == -2; }
    public static void reach(int i) { int o=observe(i); assert o!=0 && o!=1; }
}
