public final class StockCase161 {
    public static int observe(int low, int high) {
        if (!((0 <= low && low <= high))) return 2;
        int expected = 0;
        int result;
        try { result = bench.real.Midpoint.midpoint(low, high); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (low <= result && result <= high) ? 1 : 0;
    }
    public static void target(int low, int high) { int o=observe(low, high); assert o==2 || o==1 || o == -2; }
    public static void reach(int low, int high) { int o=observe(low, high); assert o!=0 && o!=1; }
}
