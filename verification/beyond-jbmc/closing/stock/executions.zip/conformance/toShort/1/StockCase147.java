public final class StockCase147 {
    public static int observe(int x) {
        if (!((x == 32768))) return 2;
        int expected = 0;
        short result;
        try { result = conformance.Conformance.toShort(x); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (result == -32768) ? 1 : 0;
    }
    public static void target(int x) { int o=observe(x); assert o==2 || o==1 || o == -2; }
    public static void reach(int x) { int o=observe(x); assert o!=0 && o!=1; }
}
