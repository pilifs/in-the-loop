public final class StockCase150 {
    public static int observe(char c) {
        int expected = 0;
        char result;
        try { result = conformance.Conformance.nextChar(c); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (result > c) ? 1 : 0;
    }
    public static void target(char c) { int o=observe(c); assert o==2 || o==1 || o == -2; }
    public static void reach(char c) { int o=observe(c); assert o!=0 && o!=1; }
}
