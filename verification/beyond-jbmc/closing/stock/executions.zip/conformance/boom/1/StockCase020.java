public final class StockCase020 {
    public static int observe(int n) {
        int expected = 0;
        int result;
        try { result = conformance.Conformance.boom(n); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (result == n) ? 1 : 0;
    }
    public static void target(int n) { int o=observe(n); assert o==2 || o==1 || o == -2; }
    public static void reach(int n) { int o=observe(n); assert o!=0 && o!=1; }
}
