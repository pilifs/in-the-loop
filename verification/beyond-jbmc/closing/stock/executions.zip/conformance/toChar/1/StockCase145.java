public final class StockCase145 {
    public static int observe(int x) {
        int expected = 0;
        char result;
        try { result = conformance.Conformance.toChar(x); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (result >= 0 && result <= 65535) ? 1 : 0;
    }
    public static void target(int x) { int o=observe(x); assert o==2 || o==1 || o == -2; }
    public static void reach(int x) { int o=observe(x); assert o!=0 && o!=1; }
}
