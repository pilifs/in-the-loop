public final class StockCase007 {
    public static int observe(byte[] out) {
        if (!((out != null && out.length <= 8))) return 2;
        byte entry = out.length == 0 ? 0 : out[0];
        int expected = 0;
        int result;
        try { result = conformance.Conformance.firstByte(out); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (out.length == 0 || result == entry) ? 1 : 0;
    }
    public static void target(byte[] out) { int o=observe(out); assert o==2 || o==1 || o == -2; }
    public static void reach(byte[] out) { int o=observe(out); assert o!=0 && o!=1; }
}
