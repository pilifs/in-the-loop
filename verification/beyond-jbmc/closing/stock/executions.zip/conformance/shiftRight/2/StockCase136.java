public final class StockCase136 {
    public static int observe(int x, int s) {
        if (!((s == 33))) return 2;
        int expected = 0;
        int result;
        try { result = conformance.Conformance.shiftRight(x, s); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (result == x / 2) ? 1 : 0;
    }
    public static void target(int x, int s) { int o=observe(x, s); assert o==2 || o==1 || o == -2; }
    public static void reach(int x, int s) { int o=observe(x, s); assert o!=0 && o!=1; }
}
