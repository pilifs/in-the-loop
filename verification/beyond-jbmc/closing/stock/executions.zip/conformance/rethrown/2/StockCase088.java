public final class StockCase088 {
    public static int observe(int n) {
        int expected = 0;
        if (n < 0) expected = 1;
        int result;
        try { result = conformance.Conformance.rethrown(n); }
        catch (Throwable t) {
            if (t instanceof IllegalArgumentException) return expected == 1 ? -2 : -1;
            return -1;
        }
        return expected == 0 && (result == n) ? 1 : 0;
    }
    public static void target(int n) { int o=observe(n); assert o==2 || o==1 || o == -2; }
    public static void reach(int n) { int o=observe(n); assert o!=0 && o!=1; }
}
