public final class StockCase113 {
    public static int observe(int a, int b) {
        int expected = 0;
        boolean result;
        try { result = conformance.Conformance.pairsEqual(a, b); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (!result) ? 1 : 0;
    }
    public static void target(int a, int b) { int o=observe(a, b); assert o==2 || o==1 || o == -2; }
    public static void reach(int a, int b) { int o=observe(a, b); assert o!=0 && o!=1; }
}
