public final class StockCase154 {
    public static int observe(byte a, byte b) {
        int expected = 0;
        int result;
        try { result = conformance.Conformance.byteSum(a, b); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (result >= 0) ? 1 : 0;
    }
    public static void target(byte a, byte b) { int o=observe(a, b); assert o==2 || o==1 || o == -2; }
    public static void reach(byte a, byte b) { int o=observe(a, b); assert o!=0 && o!=1; }
}
