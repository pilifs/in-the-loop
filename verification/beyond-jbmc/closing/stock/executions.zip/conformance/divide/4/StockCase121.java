public final class StockCase121 {
    public static int observe(int a, int b) {
        int expected = 0;
        int result;
        try { result = conformance.Conformance.divide(a, b); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (result * b + a % b == a) ? 1 : 0;
    }
    public static void target(int a, int b) { int o=observe(a, b); assert o==2 || o==1 || o == -2; }
    public static void reach(int a, int b) { int o=observe(a, b); assert o!=0 && o!=1; }
}
