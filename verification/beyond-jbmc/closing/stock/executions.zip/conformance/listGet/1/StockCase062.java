public final class StockCase062 {
    public static int observe(int n) {
        if (!((n == 0 || n == 12))) return 2;
        int expected = 0;
        int result;
        try { result = conformance.Conformance.listGet(n); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (result == 1) ? 1 : 0;
    }
    public static void target(int n) { int o=observe(n); assert o==2 || o==1 || o == -2; }
    public static void reach(int n) { int o=observe(n); assert o!=0 && o!=1; }
}
