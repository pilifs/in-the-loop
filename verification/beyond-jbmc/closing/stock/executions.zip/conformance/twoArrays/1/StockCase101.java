public final class StockCase101 {
    public static int observe(int[] a, int[] b) {
        if (!((a != null && a.length <= 8) && (b != null && b.length <= 8) && (b != a) && (a.length > 0 && b.length > 0))) return 2;
        int expected = 0;
        int result;
        try { result = conformance.Conformance.twoArrays(a, b); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (result == 1) ? 1 : 0;
    }
    public static void target(int[] a, int[] b) { int o=observe(a, b); assert o==2 || o==1 || o == -2; }
    public static void reach(int[] a, int[] b) { int o=observe(a, b); assert o!=0 && o!=1; }
}
