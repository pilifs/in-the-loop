public final class StockCase107 {
    public static int observe(int lo, int hi) {
        int expected = 0;
        if (lo > hi) expected = 1;
        int result;
        try { result = conformance.Conformance.width(lo, hi); }
        catch (Throwable t) {
            if (t instanceof IllegalArgumentException) return expected == 1 ? -2 : -1;
            return -1;
        }
        return expected == 0 && (result == hi - lo) ? 1 : 0;
    }
    public static void target(int lo, int hi) { int o=observe(lo, hi); assert o==2 || o==1 || o == -2; }
    public static void reach(int lo, int hi) { int o=observe(lo, hi); assert o!=0 && o!=1; }
}
