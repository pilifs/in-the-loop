public final class StockCase104 {
    public static int observe(int[] a) {
        if (!((a != null && a.length <= 8))) return 2;
        int expected = 0;
        int result;
        try { result = conformance.Conformance.lengthOrMinusOne(a); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (result >= 0) ? 1 : 0;
    }
    public static void target(int[] a) { int o=observe(a); assert o==2 || o==1 || o == -2; }
    public static void reach(int[] a) { int o=observe(a); assert o!=0 && o!=1; }
}
