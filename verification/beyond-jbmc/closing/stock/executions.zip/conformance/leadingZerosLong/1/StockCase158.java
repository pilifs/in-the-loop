public final class StockCase158 {
    public static int observe(long x) {
        int expected = 0;
        int result;
        try { result = conformance.Conformance.leadingZerosLong(x); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && ((x == 0L && result == 64) || (x != 0L && 0 <= result && result < 64 && (x >>> (63 - result)) == 1L)) ? 1 : 0;
    }
    public static void target(long x) { int o=observe(x); assert o==2 || o==1 || o == -2; }
    public static void reach(long x) { int o=observe(x); assert o!=0 && o!=1; }
}
