public final class StockCase128 {
    public static int observe(long a, long b) {
        if (!((a < 0 && b > 0))) return 2;
        int expected = 0;
        long result;
        try { result = conformance.Conformance.remainderLong(a, b); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (result >= 0) ? 1 : 0;
    }
    public static void target(long a, long b) { int o=observe(a, b); assert o==2 || o==1 || o == -2; }
    public static void reach(long a, long b) { int o=observe(a, b); assert o!=0 && o!=1; }
}
