public final class StockCase133 {
    public static int observe(long x, int s) {
        if (!((s == 64))) return 2;
        int expected = 0;
        long result;
        try { result = conformance.Conformance.shiftLeftLong(x, s); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (result == 0) ? 1 : 0;
    }
    public static void target(long x, int s) { int o=observe(x, s); assert o==2 || o==1 || o == -2; }
    public static void reach(long x, int s) { int o=observe(x, s); assert o!=0 && o!=1; }
}
