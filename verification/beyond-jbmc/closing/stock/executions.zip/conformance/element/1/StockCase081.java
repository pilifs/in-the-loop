public final class StockCase081 {
    public static int observe(int[] a, int i) {
        if (!((a != null && a.length <= 8))) return 2;
        int expected = 0;
        if (i < 0 || i >= a.length) expected = 1;
        int result;
        try { result = conformance.Conformance.element(a, i); }
        catch (Throwable t) {
            if (t instanceof ArrayIndexOutOfBoundsException) return expected == 1 ? -2 : -1;
            return -1;
        }
        return expected == 0 && (result == a[i]) ? 1 : 0;
    }
    public static void target(int[] a, int i) { int o=observe(a, i); assert o==2 || o==1 || o == -2; }
    public static void reach(int[] a, int i) { int o=observe(a, i); assert o!=0 && o!=1; }
}
