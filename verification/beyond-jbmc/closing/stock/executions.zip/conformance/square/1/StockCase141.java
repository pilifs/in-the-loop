public final class StockCase141 {
    public static int observe(int x) {
        int expected = 0;
        int result;
        try { result = conformance.Conformance.square(x); }
        catch (Throwable t) {
            return -1;
        }
        return expected == 0 && (result >= 0) ? 1 : 0;
    }
    public static void target(int x) { int o=observe(x); assert o==2 || o==1 || o == -2; }
    public static void reach(int x) { int o=observe(x); assert o!=0 && o!=1; }
}
