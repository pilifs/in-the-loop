public final class StockCase185 {
    public static int observe(int[] matches, int key) {
        if (!((matches != null && matches.length <= 8) && (matches != null))) return 2;
        for (int i=0; i+1 < matches.length; ++i) if (matches[i] >= matches[i+1]) return 2;
        int[] old_matches = new int[matches.length];
        for (int i=0; i<matches.length; ++i) old_matches[i] = matches[i];
        Throwable t0 = null;
        int v0 = 0;
        try { v0 = before.net.terminalvalue.mica.interp.LookupSwitch.find(old_matches, key); } catch (Throwable e) { t0=e; }
        Throwable t1 = null;
        int v1 = 0;
        try { v1 = net.terminalvalue.mica.interp.LookupSwitch.find(matches, key); } catch (Throwable e) { t1=e; }
        boolean normal = t0 == null && t1 == null;
        boolean equal = normal || (t0 != null && t1 != null && t0.getClass() == t1.getClass());
        if (normal && v0 != v1) equal=false;
        for (int i=0; i<matches.length; ++i) if (old_matches[i] != matches[i]) equal=false;
        return normal ? (equal ? 1 : 0) : (equal ? -2 : -1);
    }
    public static void target(int[] matches, int key) { int o=observe(matches, key); assert o==2 || o==1 || o == -2; }
    public static void reach(int[] matches, int key) { int o=observe(matches, key); assert o!=0 && o!=1; }
}
