public final class StockCase186 {
    public static int observe(char[] chars, byte[] out) {
        if (!((chars != null && chars.length <= 8) && (out != null && out.length <= 8))) return 2;
        char[] old_chars = new char[chars.length];
        for (int i=0; i<chars.length; ++i) old_chars[i] = chars[i];
        byte[] old_out = new byte[out.length];
        for (int i=0; i<out.length; ++i) old_out[i] = out[i];
        Throwable t0 = null;
        int v0 = 0;
        try { v0 = before.net.terminalvalue.mica.classfile.ModifiedUtf8.encodeInto(old_chars, old_out); } catch (Throwable e) { t0=e; }
        Throwable t1 = null;
        int v1 = 0;
        try { v1 = net.terminalvalue.mica.classfile.ModifiedUtf8.encodeInto(chars, out); } catch (Throwable e) { t1=e; }
        boolean normal = t0 == null && t1 == null;
        boolean equal = normal || (t0 != null && t1 != null && t0.getClass() == t1.getClass());
        if (normal && v0 != v1) equal=false;
        for (int i=0; i<chars.length; ++i) if (old_chars[i] != chars[i]) equal=false;
        for (int i=0; i<out.length; ++i) if (old_out[i] != out[i]) equal=false;
        return normal ? (equal ? 1 : 0) : (equal ? -2 : -1);
    }
    public static void target(char[] chars, byte[] out) { int o=observe(chars, out); assert o==2 || o==1 || o == -2; }
    public static void reach(char[] chars, byte[] out) { int o=observe(chars, out); assert o!=0 && o!=1; }
}
