public class RaggedPropertyInput {
 public static void check(int arg0i, int arg1i, long arg2j, long arg4j, int arg6i, int arg7i, long arg8j, long arg10j) {
  if (arg0i < -1 || arg0i > 2) return;
  long[][] rows = arg0i < 0 ? null : new long[arg0i][];
  if (arg0i > 0) {
   if (arg1i < -1 || arg1i > 2) return;
   if (arg1i >= 0) {
    rows[0] = new long[arg1i];
    if (arg1i > 0) rows[0][0] = arg2j;
    if (arg1i > 1) rows[0][1] = arg4j;
   }
  }
  if (arg0i > 1) {
   if (arg6i >= 0 && arg6i < 1) rows[1] = rows[arg6i]; else {
   if (arg7i < -1 || arg7i > 2) return;
   if (arg7i >= 0) {
    rows[1] = new long[arg7i];
    if (arg7i > 0) rows[1][0] = arg8j;
    if (arg7i > 1) rows[1][1] = arg10j;
   }
   }
  }
  PropertyHarness.check(rows);
 }
}
