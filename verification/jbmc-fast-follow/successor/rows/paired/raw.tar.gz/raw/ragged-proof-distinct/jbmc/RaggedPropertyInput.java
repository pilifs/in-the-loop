public class RaggedPropertyInput {
 public static void check(int arg0i, int arg1i, int arg2i, int arg3i, int arg4i, int arg5i, int arg6i, int arg7i) {
  if (arg0i < -1 || arg0i > 2) return;
  int[][] rows = arg0i < 0 ? null : new int[arg0i][];
  if (arg0i > 0) {
   if (arg1i < -1 || arg1i > 2) return;
   if (arg1i >= 0) {
    rows[0] = new int[arg1i];
    if (arg1i > 0) rows[0][0] = arg2i;
    if (arg1i > 1) rows[0][1] = arg3i;
   }
  }
  if (arg0i > 1) {
   if (arg4i >= 0 && arg4i < 1) rows[1] = rows[arg4i]; else {
   if (arg5i < -1 || arg5i > 2) return;
   if (arg5i >= 0) {
    rows[1] = new int[arg5i];
    if (arg5i > 0) rows[1][0] = arg6i;
    if (arg5i > 1) rows[1][1] = arg7i;
   }
   }
  }
  PropertyHarness.check(rows);
 }
}
