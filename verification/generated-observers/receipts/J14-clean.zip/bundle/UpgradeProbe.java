import java.util.*;
import java.io.*;

// The reviewed input is data. The evaluator and its predictions are outside this class.
public final class UpgradeProbe {
    private static final class Inputs {
        final String[] words;
        int index;
        Inputs(String[] words) { this.words = words; }

        Object read() {
            String word = words[index++];
            String value = word.substring(1);
            switch (word.charAt(0)) {
                case 's': return value;
                case 'i': return Integer.valueOf(value);
                case 'b': return Boolean.valueOf(value);
                case 'n': return null;
                case 'a': {
                    List<Object> list = new ArrayList<>();
                    for (int i = Integer.parseInt(value); i > 0; i--) list.add(read());
                    return list;
                }
                case 'm': {
                    Map<String,Object> map = new LinkedHashMap<>();
                    for (int i = Integer.parseInt(value); i > 0; i--) map.put((String)read(), read());
                    return map;
                }
                default: throw new IllegalArgumentException("unknown input type");
            }
        }
    }
    @SuppressWarnings("unchecked")
    private static Map<String,Object> input(String[] words) {
        Inputs in = new Inputs(words);
        Map<String,Object> value = (Map<String,Object>)in.read();
        if (in.index != words.length) throw new IllegalArgumentException("extra input");
        return value;
    }

    private static List<Object> row(Object... fields) { return Arrays.asList(fields); }

    private static void encode(StringBuilder out, Object value) {
        if (value instanceof List<?>) {
            out.append('[');
            boolean first = true;
            for (Object item : (List<?>)value) {
                if (!first) out.append(',');
                encode(out, item);
                first = false;
            }
            out.append(']');
        } else if (value instanceof String) {
            out.append('"');
            for (char ch : ((String)value).toCharArray()) {
                switch (ch) {
                    case '"': out.append("\\\""); break;
                    case '\\': out.append("\\\\"); break;
                    case '\b': out.append("\\b"); break;
                    case '\t': out.append("\\t"); break;
                    case '\n': out.append("\\n"); break;
                    case '\f': out.append("\\f"); break;
                    case '\r': out.append("\\r"); break;
                    default:
                        if (ch < 32 || ch > 126) out.append(String.format(Locale.ROOT, "\\u%04x", (int)ch));
                        else out.append(ch);
                }
            }
            out.append('"');
        } else if (value == null || value instanceof Boolean || value instanceof Number) {
            out.append(String.valueOf(value));
        } else throw new IllegalArgumentException("unsupported public field " + value.getClass().getName());
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static String observe(String[] args) throws Exception {
        Map<String,Object> data = input(args);
        List<Object> observations = new ArrayList<>();
        try (org.apache.lucene.store.ByteBuffersDirectory directory = new org.apache.lucene.store.ByteBuffersDirectory()) {
            try (org.apache.lucene.index.IndexWriter writer = new org.apache.lucene.index.IndexWriter(directory, new org.apache.lucene.index.IndexWriterConfig())) {
                for (Map<String,Object> block : (List<Map<String,Object>>)data.get("blocks")) {
                    List<org.apache.lucene.document.Document> docs = new ArrayList<>();
                    for (Integer value : (List<Integer>)block.get("children")) {
                        org.apache.lucene.document.Document child = new org.apache.lucene.document.Document();
                        child.add(new org.apache.lucene.document.StringField("role","child", org.apache.lucene.document.Field.Store.NO));
                        if (value != null) {
                            child.add(new org.apache.lucene.document.StringField("valued","yes",org.apache.lucene.document.Field.Store.NO));
                            child.add(new org.apache.lucene.document.SortedDocValuesField("spelling",new org.apache.lucene.util.BytesRef(value.toString())));
                            child.add(new org.apache.lucene.document.SortedNumericDocValuesField("number",value));
                        }
                        docs.add(child);
                    }
                    org.apache.lucene.document.Document parent = new org.apache.lucene.document.Document();
                    parent.add(new org.apache.lucene.document.StringField("role","parent",org.apache.lucene.document.Field.Store.NO));
                    parent.add(new org.apache.lucene.document.StoredField("identity",(String)block.get("parent")));
                    docs.add(parent);
                    writer.addDocuments(docs);
                }
            }
            try (org.apache.lucene.index.DirectoryReader reader = org.apache.lucene.index.DirectoryReader.open(directory)) {
                org.apache.lucene.search.IndexSearcher searcher = new org.apache.lucene.search.IndexSearcher(reader);
                org.apache.lucene.search.TermQuery parents = new org.apache.lucene.search.TermQuery(new org.apache.lucene.index.Term("role","parent"));
                boolean filtered = (Boolean)data.get("excludeMissingChild");
                org.apache.lucene.search.join.BitSetProducer parentFilter = new org.apache.lucene.search.join.QueryBitSetProducer(parents);
                org.apache.lucene.search.join.BitSetProducer childFilter = new org.apache.lucene.search.join.QueryBitSetProducer(new org.apache.lucene.search.TermQuery(
                        new org.apache.lucene.index.Term(filtered ? "valued" : "role",filtered ? "yes" : "child")));
                boolean reverse = data.get("order").equals("descending");
                org.apache.lucene.search.SortField ordering = new org.apache.lucene.search.join.ToParentBlockJoinSortField("spelling",org.apache.lucene.search.SortField.Type.STRING,reverse,parentFilter,childFilter);
                observations.add(hits(searcher,parents,ordering));
                List<Integer> missing = (List<Integer>)data.get("childMissing");
                if (!missing.isEmpty()) {
                    try {
                        java.lang.reflect.Constructor<?> withMissing = org.apache.lucene.search.join.ToParentBlockJoinSortField.class.getConstructor(String.class,
                                org.apache.lucene.search.SortField.Type.class,boolean.class,Object.class,Object.class,org.apache.lucene.search.join.BitSetProducer.class,org.apache.lucene.search.join.BitSetProducer.class);
                        for (Integer replacement : missing) {
                            org.apache.lucene.search.SortField numeric = (org.apache.lucene.search.SortField)withMissing.newInstance("number",org.apache.lucene.search.SortField.Type.INT,reverse,
                                    data.get("parentMissing"),replacement,parentFilter,childFilter);
                            observations.add(hits(searcher,parents,numeric));
                        }
                    } catch (NoSuchMethodException absent) { observations.add(row("overload-absent")); }
                }
            }
        }
        StringBuilder result = new StringBuilder();
        encode(result, observations);
        return result.toString();
    }
    private static List<Object> hits(org.apache.lucene.search.IndexSearcher searcher, org.apache.lucene.search.TermQuery parents, org.apache.lucene.search.SortField ordering) throws IOException {
        org.apache.lucene.search.TopFieldDocs found = searcher.search(parents,100,new org.apache.lucene.search.Sort(ordering));
        List<Object> values = new ArrayList<>();
        for (org.apache.lucene.search.ScoreDoc doc : found.scoreDocs) {
            Object sortKey = ((org.apache.lucene.search.FieldDoc)doc).fields[0];
            String spelling = sortKey == null ? null : sortKey instanceof org.apache.lucene.util.BytesRef ? ((org.apache.lucene.util.BytesRef)sortKey).utf8ToString() : sortKey.toString();
            values.add(row(searcher.storedFields().document(doc.doc).get("identity"),spelling));
        }
        return row(found.totalHits.value(), values);
    }
}
