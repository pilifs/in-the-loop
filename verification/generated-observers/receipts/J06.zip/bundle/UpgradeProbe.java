import java.util.*;
import java.io.*;

// The reviewed input is data. The evaluator and its predictions are outside this class.
public final class UpgradeProbe {
    private static final class Inputs {
        final String[] words;
        int index;
        Inputs(String[] words) { this.words = words; }

        Object read() {
            String word = words[index++];
            String value = word.substring(1);
            switch (word.charAt(0)) {
                case 's': return value;
                case 'i': return Integer.valueOf(value);
                case 'b': return Boolean.valueOf(value);
                case 'n': return null;
                case 'a': {
                    List<Object> list = new ArrayList<>();
                    for (int i = Integer.parseInt(value); i > 0; i--) list.add(read());
                    return list;
                }
                case 'm': {
                    Map<String,Object> map = new LinkedHashMap<>();
                    for (int i = Integer.parseInt(value); i > 0; i--) map.put((String)read(), read());
                    return map;
                }
                default: throw new IllegalArgumentException("unknown input type");
            }
        }
    }
    @SuppressWarnings("unchecked")
    private static Map<String,Object> input(String[] words) {
        Inputs in = new Inputs(words);
        Map<String,Object> value = (Map<String,Object>)in.read();
        if (in.index != words.length) throw new IllegalArgumentException("extra input");
        return value;
    }

    private static List<Object> row(Object... fields) { return Arrays.asList(fields); }

    private static void encode(StringBuilder out, Object value) {
        if (value instanceof List<?>) {
            out.append('[');
            boolean first = true;
            for (Object item : (List<?>)value) {
                if (!first) out.append(',');
                encode(out, item);
                first = false;
            }
            out.append(']');
        } else if (value instanceof String) {
            out.append('"');
            for (char ch : ((String)value).toCharArray()) {
                switch (ch) {
                    case '"': out.append("\\\""); break;
                    case '\\': out.append("\\\\"); break;
                    case '\b': out.append("\\b"); break;
                    case '\t': out.append("\\t"); break;
                    case '\n': out.append("\\n"); break;
                    case '\f': out.append("\\f"); break;
                    case '\r': out.append("\\r"); break;
                    default:
                        if (ch < 32 || ch > 126) out.append(String.format(Locale.ROOT, "\\u%04x", (int)ch));
                        else out.append(ch);
                }
            }
            out.append('"');
        } else if (value == null || value instanceof Boolean || value instanceof Number) {
            out.append(String.valueOf(value));
        } else throw new IllegalArgumentException("unsupported public field " + value.getClass().getName());
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static String observe(String[] args) throws Exception {
        Map<String,Object> data = input(args);
        List<Object> observations = new ArrayList<>();
        File file = new File("fixture.zip");
        try (java.util.zip.ZipOutputStream out = new java.util.zip.ZipOutputStream(new FileOutputStream(file))) {
            for (Map<String,String> item : (List<Map<String,String>>)data.get("entries")) {
                java.util.zip.ZipEntry entry = new java.util.zip.ZipEntry(item.get("name"));
                entry.setTime(946684800000L);
                out.putNextEntry(entry);
                out.write(bytes(item.get("payload")));
                out.closeEntry();
            }
        }
        List<String> names = (List<String>)data.get("names");
        for (int i=1; i<names.size(); i++) {
            new net.lingala.zip4j.ZipFile(file).renameFile(names.get(i-1), names.get(i));
            try (java.util.zip.ZipFile archive = new java.util.zip.ZipFile(file)) {
                TreeMap<String,List<Object>> entries = new TreeMap<>();
                for (java.util.zip.ZipEntry entry : Collections.list(archive.entries())) {
                    ByteArrayOutputStream contents = new ByteArrayOutputStream();
                    try (InputStream in = archive.getInputStream(entry)) {
                        byte[] buf = new byte[256];
                        for (int n; (n=in.read(buf)) != -1;) contents.write(buf, 0, n);
                    }
                    if (entries.put(entry.getName(), row(entry.getName(), entry.isDirectory(), hex(contents.toByteArray()))) != null)
                        throw new IllegalStateException("ambiguous duplicated archive name");
                }
                observations.add(new ArrayList<>(entries.values()));
            }
        }
        StringBuilder result = new StringBuilder();
        encode(result, observations);
        return result.toString();
    }
    private static byte[] bytes(String text) {
        byte[] bytes = new byte[text.length()/2];
        for (int i=0; i<bytes.length; i++) bytes[i]=(byte)Integer.parseInt(text.substring(2*i, 2*i+2), 16);
        return bytes;
    }
    private static String hex(byte[] bytes) {
        StringBuilder value = new StringBuilder();
        for (byte b : bytes) value.append(String.format(Locale.ROOT, "%02x", b & 255));
        return value.toString();
    }
}
