import java.util.*;
import java.io.*;

// The reviewed input is data. The evaluator and its predictions are outside this class.
public final class UpgradeProbe {
    private static final class Inputs {
        final String[] words;
        int index;
        Inputs(String[] words) { this.words = words; }

        Object read() {
            String word = words[index++];
            String value = word.substring(1);
            switch (word.charAt(0)) {
                case 's': return value;
                case 'i': return Integer.valueOf(value);
                case 'b': return Boolean.valueOf(value);
                case 'n': return null;
                case 'a': {
                    List<Object> list = new ArrayList<>();
                    for (int i = Integer.parseInt(value); i > 0; i--) list.add(read());
                    return list;
                }
                case 'm': {
                    Map<String,Object> map = new LinkedHashMap<>();
                    for (int i = Integer.parseInt(value); i > 0; i--) map.put((String)read(), read());
                    return map;
                }
                default: throw new IllegalArgumentException("unknown input type");
            }
        }
    }
    @SuppressWarnings("unchecked")
    private static Map<String,Object> input(String[] words) {
        Inputs in = new Inputs(words);
        Map<String,Object> value = (Map<String,Object>)in.read();
        if (in.index != words.length) throw new IllegalArgumentException("extra input");
        return value;
    }

    private static List<Object> row(Object... fields) { return Arrays.asList(fields); }

    private static void encode(StringBuilder out, Object value) {
        if (value instanceof List<?>) {
            out.append('[');
            boolean first = true;
            for (Object item : (List<?>)value) {
                if (!first) out.append(',');
                encode(out, item);
                first = false;
            }
            out.append(']');
        } else if (value instanceof String) {
            out.append('"');
            for (char ch : ((String)value).toCharArray()) {
                switch (ch) {
                    case '"': out.append("\\\""); break;
                    case '\\': out.append("\\\\"); break;
                    case '\b': out.append("\\b"); break;
                    case '\t': out.append("\\t"); break;
                    case '\n': out.append("\\n"); break;
                    case '\f': out.append("\\f"); break;
                    case '\r': out.append("\\r"); break;
                    default:
                        if (ch < 32 || ch > 126) out.append(String.format(Locale.ROOT, "\\u%04x", (int)ch));
                        else out.append(ch);
                }
            }
            out.append('"');
        } else if (value == null || value instanceof Boolean || value instanceof Number) {
            out.append(String.valueOf(value));
        } else throw new IllegalArgumentException("unsupported public field " + value.getClass().getName());
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    public static String observe(String[] args) throws Exception {
        Map<String,Object> data = input(args);
        List<Object> observations = new ArrayList<>();
        for (String text : (List<String>)data.get("streams")) {
            List<Object> events = new ArrayList<>();
            String[] terminal = new String[3];
            org.springframework.web.reactive.function.client.WebClient client = org.springframework.web.reactive.function.client.WebClient.builder().exchangeFunction(request ->
                    reactor.core.publisher.Mono.just(org.springframework.web.reactive.function.client.ClientResponse.create(org.springframework.http.HttpStatus.OK)
                        .header("Content-Type", "text/event-stream").body(text).build())).build();
            org.springframework.web.reactive.function.client.WebClient.ResponseSpec response = client.get().uri("http://localhost/observed").retrieve();
            reactor.core.publisher.Flux<org.springframework.http.codec.ServerSentEvent<String>> stream = response.bodyToFlux(new org.springframework.core.ParameterizedTypeReference<org.springframework.http.codec.ServerSentEvent<String>>() {});
            stream.doOnNext(event -> events.add(row(event.data(), event.retry()==null ? null : event.retry().toMillis())))
                  .doOnComplete(() -> terminal[0]="complete")
                  .doOnError(error -> {
                      terminal[0]="error";
                      terminal[1]=error.getClass().getName();
                      terminal[2]=error.getCause()==null ? null : error.getCause().getClass().getName();
                  }).onErrorResume(error -> reactor.core.publisher.Flux.empty()).blockLast(java.time.Duration.ofSeconds(10));
            observations.add(row(events, terminal[0], terminal[1], terminal[2]));
        }
        StringBuilder result = new StringBuilder();
        encode(result, observations);
        return result.toString();
    }

}
