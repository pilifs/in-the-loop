package trial;
public class PublicValue {
  public static int sample(int x) { return 3; }
}
