#!/bin/sh
# Run from any directory with a JDK 17+ on PATH.
set -eu
cd "$(dirname "$0")"
work_dir=$(mktemp -d)
trap 'rm -rf "$work_dir"' EXIT
for revision in base regression repair
do
    mkdir -p "$work_dir/$revision"
    java -m jdk.compiler/com.sun.tools.javac.Main -d "$work_dir/$revision" "$revision/gradebook/ScoreSheet.java"
done
java Check.java "$work_dir/base" "$work_dir/regression" "$work_dir/repair"
