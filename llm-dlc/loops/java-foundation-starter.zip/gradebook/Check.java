import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.Path;
import java.util.Arrays;

public class Check {
    static final class Counts {
        int inputs, returnErrors, postErrors, interior, interiorPostErrors, frameErrors;
        String firstMismatch;
    }

    static int[] sheet(int length, int encoding) {
        int[] scores = new int[length];
        for (int i = 0; i < length; i++) {
            scores[i] = encoding % 3;
            encoding /= 3;
        }
        return scores;
    }

    static Counts compare(Path classes) throws Exception {
        Counts counts = new Counts();
        URL[] urls = {classes.toUri().toURL()};
        try (var loader = new URLClassLoader(urls, ClassLoader.getPlatformClassLoader())) {
            Method write = loader.loadClass("gradebook.ScoreSheet").getMethod(
                    "write", int[].class, int.class, int.class);
            int combinations = 1;
            for (int length = 1; length <= 3; length++) {
                combinations *= 3;
                for (int n = 0; n < combinations; n++) {
                    int[] original = sheet(length, n);
                    for (int slot = 0; slot < length; slot++) {
                        for (int score = 0; score <= 2; score++) {
                            int[] actual = original.clone();
                            int result = (int) write.invoke(null, actual, slot, score);
                            boolean interior = slot + 1 < length;
                            counts.inputs++;
                            if (interior) counts.interior++;
                            if (result != original[slot]) counts.returnErrors++;
                            boolean stateMatches = true;
                            for (int i = 0; i < length; i++) {
                                int expected = (i == slot) ? score : original[i];
                                if (actual[i] != expected) {
                                    stateMatches = false;
                                    if (i != slot) counts.frameErrors++;
                                }
                            }
                            if (!stateMatches) {
                                counts.postErrors++;
                                if (interior) counts.interiorPostErrors++;
                                if (counts.firstMismatch == null) {
                                    counts.firstMismatch = Arrays.toString(original) + " slot " + slot
                                        + " score " + score + " actual " + Arrays.toString(actual);
                                }
                            }
                        }
                    }
                }
            }
        }
        return counts;
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 3) throw new IllegalArgumentException("Supply base, regression and repair class directories");
        int[] expectedPostErrors = {0, 78, 0};
        for (int i = 0; i < args.length; i++) {
            Counts c = compare(Path.of(args[i]));
            System.out.printf("%s: cases=%d interior=%d returnErrors=%d postErrors=%d interiorPostErrors=%d frameErrors=%d first=%s%n",
                    args[i], c.inputs, c.interior, c.returnErrors, c.postErrors, c.interiorPostErrors, c.frameErrors, c.firstMismatch);
            if (c.inputs != 306 || c.interior != 189 || c.returnErrors != 0
                    || c.postErrors != expectedPostErrors[i] || c.interiorPostErrors != 0 || c.frameErrors != 0) {
                throw new AssertionError("Unexpected finite-domain outcomes");
            }
        }
    }
}
