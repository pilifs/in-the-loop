# Gradebook finite-domain calibration

Run `sh run.sh` with a JDK 17 or later. The script compiles the same fully qualified method for three gradebook revisions, loads each from its own class directory, and checks its result and mutated array against a per-element specification. It requires no external dependencies.

**Entry** `gradebook.ScoreSheet.write(int[] scores, int slot, int score)` returns the previous mark and updates the selected slot. The baseline always assigns. The regression skips the last slot. The repaired version skips only redundant assignments.

**Finite domain** Non-null arrays of length 1 to 3, existing marks and new mark from 0 to 2, and any valid slot. There are 306 inputs, 189 with interior slots. The check compares each final cell with the specification and also counts frame violations (changed cells outside the selected slot).

| Revision | Return mismatches | Poststate mismatches | Interior poststate mismatches | Frame violations |
|---|---:|---:|---:|---:|
| Baseline | 0 | 0 | 0 | 0 |
| Regression | 0 | 78 | 0 | 0 |
| Repair | 0 | 0 | 0 | 0 |

The first failing input is `scores=[0], slot=0, score=1`. All revisions return 0. The regression leaves `[0]`; the baseline and repair produce `[1]`. The witness belongs to the full domain and falls outside the interior-only input domain.

This is an independent exhaustive JVM calibration at the stated bound. To exercise the proof factory, package the same entry for its ordinary route, declare each observation and input domain as a separate claim, check witness membership, and compare its accepted evidence with these expectations.
