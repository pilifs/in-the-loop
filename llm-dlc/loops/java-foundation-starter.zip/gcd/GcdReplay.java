import org.apache.commons.math.util.MathUtils;

public final class GcdReplay {
    public static void main(String[] args) {
        int failures = 0;
        int preservedFailures = 0;
        for (int i = 0; i <= 20; i++) {
            for (int j = 0; j <= 20; j++) {
                int u = 1 << i;
                int v = 1 << j;
                int expected = 1 << Math.min(i, j);
                if (MathUtils.gcd(u, v) != expected) {
                    failures++;
                }
            }
        }
        for (int n = 0; n <= 255; n++) {
            if (MathUtils.gcd(0, n) != n) {
                preservedFailures++;
            }
        }
        System.out.printf("power-pair mismatches=%d/441 zero-law mismatches=%d/256 witness(65536,65536)=%d upstream-case=%d%n",
             failures, preservedFailures, MathUtils.gcd(65536,65536), MathUtils.gcd(3*(1<<20),9*(1<<15)));
    }
}
