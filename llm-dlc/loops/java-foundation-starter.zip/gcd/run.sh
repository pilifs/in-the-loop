#!/bin/sh
set -eu

if [ "$#" -ne 2 ]; then
    echo "Usage: sh gcd/run.sh /path/to/parent/MathUtils.java /path/to/fix/MathUtils.java" >&2
    exit 2
fi
source_dir=$(cd "$(dirname "$0")" && pwd)
scratch_dir=$(mktemp -d)
trap 'rm -rf "$scratch_dir"' EXIT

run_revision() {
    label=$1
    source_file=$2
    blob=$3
    expected=$4
    checkout_dir="$scratch_dir/$label"
    mkdir -p "$checkout_dir/classes"
    cp "$source_file" "$checkout_dir/MathUtils.java"
    actual_blob=$(git hash-object "$checkout_dir/MathUtils.java")
    if [ "$actual_blob" != "$blob" ]; then
        echo "$label source does not match pinned Git blob" >&2
        exit 1
    fi
    java -m jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 -d "$checkout_dir/classes" \
        "$checkout_dir/MathUtils.java" "$source_dir/GcdReplay.java"
    result=$(java -cp "$checkout_dir/classes" GcdReplay)
    echo "$label $result"
    if [ "$result" != "$expected" ]; then
        echo "Unexpected $label finite-domain result" >&2
        exit 1
    fi
}

run_revision parent "$1" c5342aeb30d48fbb54356d2541fae0cb6b8ddc44 \
    'power-pair mismatches=45/441 zero-law mismatches=0/256 witness(65536,65536)=131072 upstream-case=3440640'
run_revision fix "$2" df714052fb47f5b29002de29cf590c97121c322c \
    'power-pair mismatches=0/441 zero-law mismatches=0/256 witness(65536,65536)=65536 upstream-case=98304'
