# JVM reference cases for the foundation campaign

Run these finite checks from the extracted directory with a JDK (tested with OpenJDK 21.0.13). The first two need only the files in this archive.

| Case | Command | Expected result |
|---|---|---|
| Gradebook | `sh gradebook/run.sh` | 306 inputs per revision. All three return the previous mark. Only the regression produces poststate errors (78 overall, zero in the 189 interior cases). |
| Two array roots | `java alias/AliasedArrays.java` | 71 inputs, 0 different returns, 3 differing right-root poststates, 21 differing combined poststates. |
| Apache Commons Math MATH-238 | `sh gcd/run.sh /path/to/parent/MathUtils.java /path/to/fix/MathUtils.java` | Parent has 45 power-pair mismatches, fix has 0. Both pass all 256 zero-input checks. |

For GCD, use the unmodified src/java/org/apache/commons/math/util/MathUtils.java files from Apache Commons Math commits `4564adbf19ebc6da19befcc7dbef310a00b4de13` and `dabf3a5beb9ab697d570154b9961078a8586c787`. From an upstream checkout, git show REV:src/java/org/apache/commons/math/util/MathUtils.java recovers each file. The driver checks the Git blob ID and compiles the complete file in an isolated class directory. It does not modify your checkout. [Apache fix](https://github.com/apache/commons-math/commit/dabf3a5beb9ab697d570154b9961078a8586c787)

These programs compute expected outcomes independently of jvmcontract. Use their finite results and witnesses to challenge the public verification route. A solver verdict, JVM replay, admitted witness and accepted receipt are separate records.

### ThreeTenBP complete-hours replay

The additional `civil-time/CivilReplay.java` harness takes the original ThreeTenBP production classes or a JAR from the pinned revision on its classpath. Run `java --class-path PATH_TO_CLASSES civil-time/CivilReplay.java` once for each revision. The pair of dates has 192 quarter-hour ticks and 36,864 ordered pairs. The parent had 6,912 incorrect complete-hour answers, the fixed revision had zero. Both passed same-day and reversal checks.

Parent commit `fea38bd81e10d35ef8d991a4463733587e3ee7bc`, fix `f0b2eaf1856b7fb5fdf78de3cedc9781b6619b88`. A source build of this historical tree on JDK 21 needs `--add-exports java.base/sun.util.calendar=ALL-UNNAMED` at compile time for an unrelated chronology class. [Upstream fix](https://github.com/ThreeTen/threetenbp/commit/f0b2eaf1856b7fb5fdf78de3cedc9781b6619b88)
