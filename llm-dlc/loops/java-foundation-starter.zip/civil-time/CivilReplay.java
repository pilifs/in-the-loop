import org.threeten.bp.LocalDateTime;
import org.threeten.bp.temporal.ChronoUnit;

public class CivilReplay {
    public static void main(String[] args) {
        LocalDateTime[] times = new LocalDateTime[192];
        for (int i = 0; i < times.length; i++) {
            int minute = i * 15;
            times[i] = LocalDateTime.of(2012, 6, 15 + minute / 1440, (minute / 60) % 24, minute % 60);
        }
        long bad = 0, sameDayBad = 0, antisymmetryBad = 0;
        for (int i = 0; i < times.length; i++) {
            for (int j = 0; j < times.length; j++) {
                long actual = times[i].until(times[j], ChronoUnit.HOURS);
                long expected = ((j - i) * 15) / 60;
                if (actual != expected) {
                    bad++;
                    if (i / 96 == j / 96) sameDayBad++;
                }
                if (actual != -times[j].until(times[i], ChronoUnit.HOURS)) antisymmetryBad++;
            }
        }
        System.out.printf("pairs=%d mismatch=%d sameDayMismatch=%d antisymmetryMismatch=%d 23:30->00:15=%d reversed=%d%n",
            times.length * times.length, bad, sameDayBad, antisymmetryBad,
            times[94].until(times[97], ChronoUnit.HOURS),
            times[97].until(times[94], ChronoUnit.HOURS));
    }
}
