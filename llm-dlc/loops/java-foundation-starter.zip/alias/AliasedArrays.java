import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class AliasedArrays {
    record Input(int[] left, int[] right, boolean shared) {
        Heap freshHeap() {
            int[] l = left == null ? null : left.clone();
            int[] r = shared ? l : (right == null ? null : right.clone());
            return new Heap(l, r);
        }
    }

    record Heap(int[] left, int[] right) {}

    static int reference(int[] left, int[] right) {
        if (left != null && right != null && left.length > 0 && right.length > 0) {
            left[0] = 1;
        }
        return 0;
    }

    static int control(int[] left, int[] right) {
        return 0;
    }

    static List<Input> inputs() {
        List<int[]> contents = List.of(new int[]{}, new int[]{0}, new int[]{1},
                new int[]{0, 0}, new int[]{0, 1}, new int[]{1, 0}, new int[]{1, 1});
        List<Input> all = new ArrayList<>();
        all.add(new Input(null, null, false));
        for (int[] a : contents) {
            all.add(new Input(a, null, false));
            all.add(new Input(null, a, false));
            all.add(new Input(a, a, true));
            for (int[] b : contents) {
                all.add(new Input(a, b, false));
            }
        }
        return all;
    }

    public static void main(String[] args) {
        int returnDifferences = 0;
        int rightDifferences = 0;
        int eitherDifferences = 0;
        List<Input> all = inputs();
        for (Input in : all) {
            Heap before = in.freshHeap();
            Heap after = in.freshHeap();
            if (in.left != null && in.right != null
                    && ((before.left == before.right) != in.shared || (after.left == after.right) != in.shared)) {
                throw new AssertionError("Harness changed the input alias relation");
            }
            int a = reference(before.left, before.right);
            int b = control(after.left, after.right);
            boolean rightDiff = !Arrays.equals(before.right, after.right);
            boolean eitherDiff = rightDiff || !Arrays.equals(before.left, after.left);
            boolean expectedWriteChangesValue = in.left != null && in.left.length > 0 && in.left[0] == 0
                    && in.right != null && in.right.length > 0;
            if (a != b) returnDifferences++;
            if (rightDiff) rightDifferences++;
            if (eitherDiff) eitherDifferences++;
            if (rightDiff != (expectedWriteChangesValue && in.shared) || eitherDiff != expectedWriteChangesValue) {
                throw new AssertionError("Observed the wrong projection");
            }
        }
        System.out.printf("cases=%d returnDifferences=%d rightDifferences=%d eitherDifferences=%d%n",
                all.size(), returnDifferences, rightDifferences, eitherDifferences);
        if (all.size() != 71 || returnDifferences != 0 || rightDifferences != 3 || eitherDifferences != 21) {
            throw new AssertionError("Unexpected finite-domain counts");
        }
    }
}
